(() => {
    const PRODUCTS_API_URL = 'https://gist.githubusercontent.com/sevindi/5765c5812bbc8238a38b3cf52f233651/raw/56261d81af8561bf0a7cf692fe572f9e1e91f372/products.json';
    const STORAGE_KEYS = {
        PRODUCTS: 'lcw_carousel_products',
        FAVORITES: 'lcw_carousel_favorites',
        CACHE_TIMESTAMP: 'lcw_carousel_cache_time'
    };
    const CACHE_DURATION = 30 * 60 * 1000; // 30 minutes
    
    let self = {
        products: [],
        favorites: new Set(),
        currentSlide: 0,
        slidesPerView: 4,
        carouselContainer: null,
        isInitialized: false
    };

    const init = () => {
        // Saf JavaScript control element
        const isProductPage = document.querySelector('.product-detail') !== null;
        
        if (!isProductPage || self.isInitialized) return;
        
        loadJQueryIfNeeded().then(() => {
            loadFavorites();
            loadProducts().then(products => {
                if (products && products.length > 0) {
                    self.products = products;
                    buildHTML();
                    buildCSS();
                    setEvents();
                    updateSlidesPerView();
                    self.isInitialized = true;
                }
            });
        });
    };

    const loadJQueryIfNeeded = () => {
        return new Promise((resolve) => {
            if (typeof jQuery !== 'undefined' || typeof $ !== 'undefined') {
                resolve();
                return;
            }
            
            const script = document.createElement('script');
            script.src = 'https://code.jquery.com/jquery-3.6.0.min.js';
            script.onload = resolve;
            document.head.appendChild(script);
        });
    };

    const loadProducts = async () => {
        try {
            const cachedData = getCachedProducts();
            if (cachedData) {
                return cachedData;
            }

            const response = await fetch(PRODUCTS_API_URL);
            const products = await response.json();
            
            cacheProducts(products);
            return products;
        } catch (error) {
            console.error('Error loading products:', error);
            return getCachedProducts() || [];
        }
    };

    const getCachedProducts = () => {
        try {
            const cachedTime = localStorage.getItem(STORAGE_KEYS.CACHE_TIMESTAMP);
            const currentTime = Date.now();
            
            if (cachedTime && (currentTime - parseInt(cachedTime)) < CACHE_DURATION) {
                const cached = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
                return cached ? JSON.parse(cached) : null;
            }
            
            return null;
        } catch (error) {
            return null;
        }
    };

    const cacheProducts = (products) => {
        try {
            localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
            localStorage.setItem(STORAGE_KEYS.CACHE_TIMESTAMP, Date.now().toString());
        } catch (error) {
            console.warn('Unable to cache products:', error);
        }
    };

    const loadFavorites = () => {
        try {
            const saved = localStorage.getItem(STORAGE_KEYS.FAVORITES);
            self.favorites = saved ? new Set(JSON.parse(saved)) : new Set();
        } catch (error) {
            self.favorites = new Set();
        }
    };

    const saveFavorites = () => {
        try {
            localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify([...self.favorites]));
        } catch (error) {
            console.warn('Unable to save favorites:', error);
        }
    };

    const buildHTML = () => {
        const html = `
            <div class="lcw-product-carousel">
                <div class="lcw-carousel-header">
                    <h2 class="lcw-carousel-title">You Might Also Like</h2>
                </div>
                <div class="lcw-carousel-container">
                    <button class="lcw-carousel-nav lcw-nav-prev" data-direction="prev">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                    <div class="lcw-carousel-wrapper">
                        <div class="lcw-carousel-track">
                            ${self.products.map(product => createProductHTML(product)).join('')}
                        </div>
                    </div>
                    <button class="lcw-carousel-nav lcw-nav-next" data-direction="next">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <path d="M9 18L15 12L9 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                </div>
                <div class="lcw-carousel-dots">
                    ${generateDots()}
                </div>
            </div>
        `;

        $('.product-detail').after(html);
        self.carouselContainer = $('.lcw-product-carousel');
    };

    const createProductHTML = (product) => {
        const isFavorite = self.favorites.has(product.id);
        const discountPercentage = Math.round(((product.price - product.discount_price) / product.price) * 100);
        
        return `
            <div class="lcw-product-item" data-product-id="${product.id}">
                <div class="lcw-product-card">
                    <div class="lcw-product-image-container">
                        <img src="${product.image}" alt="${product.name}" class="lcw-product-image" loading="lazy">
                        <button class="lcw-favorite-btn ${isFavorite ? 'active' : ''}" data-product-id="${product.id}">
                            <svg class="lcw-heart-icon" width="20" height="20" viewBox="0 0 24 24">
                                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                            </svg>
                        </button>
                        ${discountPercentage > 0 ? `<div class="lcw-discount-badge">-${discountPercentage}%</div>` : ''}
                    </div>
                    <div class="lcw-product-info">
                        <h3 class="lcw-product-name">${product.name}</h3>
                        <div class="lcw-product-price">
                            <span class="lcw-current-price">${formatPrice(product.discount_price || product.price)}</span>
                            ${product.discount_price && product.discount_price < product.price ? 
                                `<span class="lcw-original-price">${formatPrice(product.price)}</span>` : ''}
                        </div>
                        <div class="lcw-product-rating">
                            ${generateStars(product.rating)}
                            <span class="lcw-rating-count">(${product.reviews || 0})</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    };

    const generateStars = (rating) => {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 !== 0;
        let stars = '';

        for (let i = 0; i < fullStars; i++) {
            stars += '<span class="lcw-star filled">★</span>';
        }
        
        if (hasHalfStar) {
            stars += '<span class="lcw-star half">★</span>';
        }
        
        const remainingStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
        for (let i = 0; i < remainingStars; i++) {
            stars += '<span class="lcw-star">★</span>';
        }

        return stars;
    };

    const generateDots = () => {
        const totalSlides = Math.ceil(self.products.length / self.slidesPerView);
        let dots = '';
        for (let i = 0; i < totalSlides; i++) {
            dots += `<button class="lcw-dot ${i === 0 ? 'active' : ''}" data-slide="${i}"></button>`;
        }
        return dots;
    };

    const formatPrice = (price) => {
        return new Intl.NumberFormat('tr-TR', {
            style: 'currency',
            currency: 'TRY',
            minimumFractionDigits: 2
        }).format(price);
    };

    const buildCSS = () => {
        const css = `
            .lcw-product-carousel {
                margin: 40px 0;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                background: #fff;
                border-radius: 12px;
                box-shadow: 0 2px 20px rgba(0,0,0,0.08);
                overflow: hidden;
            }

            .lcw-carousel-header {
                padding: 24px 24px 16px;
                border-bottom: 1px solid #f0f0f0;
            }

            .lcw-carousel-title {
                margin: 0;
                font-size: 24px;
                font-weight: 600;
                color: #333;
                text-align: center;
            }

            .lcw-carousel-container {
                position: relative;
                padding: 20px 60px;
            }

            .lcw-carousel-wrapper {
                overflow: hidden;
                border-radius: 8px;
            }

            .lcw-carousel-track {
                display: flex;
                transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
                gap: 16px;
            }

            .lcw-product-item {
                flex: 0 0 calc(25% - 12px);
                min-width: 200px;
            }

            .lcw-product-card {
                background: #fff;
                border-radius: 12px;
                overflow: hidden;
                transition: all 0.3s ease;
                border: 1px solid #e8e8e8;
                cursor: pointer;
                height: 100%;
                display: flex;
                flex-direction: column;
            }

            .lcw-product-card:hover {
                transform: translateY(-4px);
                box-shadow: 0 8px 32px rgba(0,0,0,0.12);
                border-color: #d0d0d0;
            }

            .lcw-product-image-container {
                position: relative;
                aspect-ratio: 3/4;
                overflow: hidden;
            }

            .lcw-product-image {
                width: 100%;
                height: 100%;
                object-fit: cover;
                transition: transform 0.3s ease;
            }

            .lcw-product-card:hover .lcw-product-image {
                transform: scale(1.05);
            }

            .lcw-favorite-btn {
                position: absolute;
                top: 12px;
                right: 12px;
                background: rgba(255,255,255,0.9);
                border: none;
                border-radius: 50%;
                width: 36px;
                height: 36px;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                transition: all 0.2s ease;
                backdrop-filter: blur(4px);
            }

            .lcw-favorite-btn:hover {
                background: rgba(255,255,255,1);
                transform: scale(1.1);
            }

            .lcw-heart-icon {
                fill: none;
                stroke: #666;
                stroke-width: 1.5;
                transition: all 0.2s ease;
            }

            .lcw-favorite-btn.active .lcw-heart-icon {
                fill: #2196F3;
                stroke: #2196F3;
            }

            .lcw-discount-badge {
                position: absolute;
                top: 12px;
                left: 12px;
                background: #ff4757;
                color: white;
                padding: 6px 10px;
                border-radius: 16px;
                font-size: 12px;
                font-weight: 600;
            }

            .lcw-product-info {
                padding: 16px;
                flex: 1;
                display: flex;
                flex-direction: column;
            }

            .lcw-product-name {
                margin: 0 0 8px 0;
                font-size: 14px;
                font-weight: 500;
                color: #333;
                line-height: 1.4;
                height: 2.8em;
                overflow: hidden;
                display: -webkit-box;
                -webkit-line-clamp: 2;
                -webkit-box-orient: vertical;
            }

            .lcw-product-price {
                margin-bottom: 8px;
                display: flex;
                align-items: center;
                gap: 8px;
            }

            .lcw-current-price {
                font-size: 16px;
                font-weight: 600;
                color: #2196F3;
            }

            .lcw-original-price {
                font-size: 14px;
                color: #999;
                text-decoration: line-through;
            }

            .lcw-product-rating {
                display: flex;
                align-items: center;
                gap: 4px;
                margin-top: auto;
            }

            .lcw-star {
                color: #e0e0e0;
                font-size: 14px;
            }

            .lcw-star.filled {
                color: #ffc107;
            }

            .lcw-star.half {
                background: linear-gradient(90deg, #ffc107 50%, #e0e0e0 50%);
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                background-clip: text;
            }

            .lcw-rating-count {
                font-size: 12px;
                color: #666;
                margin-left: 4px;
            }

            .lcw-carousel-nav {
                position: absolute;
                top: 50%;
                transform: translateY(-50%);
                background: rgba(255,255,255,0.95);
                border: 1px solid #e0e0e0;
                border-radius: 50%;
                width: 44px;
                height: 44px;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                transition: all 0.2s ease;
                z-index: 2;
                backdrop-filter: blur(4px);
            }

            .lcw-carousel-nav:hover {
                background: white;
                transform: translateY(-50%) scale(1.1);
                box-shadow: 0 4px 16px rgba(0,0,0,0.15);
            }

            .lcw-nav-prev {
                left: 12px;
            }

            .lcw-nav-next {
                right: 12px;
            }

            .lcw-carousel-nav:disabled {
                opacity: 0.5;
                cursor: not-allowed;
                transform: translateY(-50%);
            }

            .lcw-carousel-dots {
                display: flex;
                justify-content: center;
                gap: 8px;
                padding: 20px;
            }

            .lcw-dot {
                width: 8px;
                height: 8px;
                border-radius: 50%;
                border: none;
                background: #d0d0d0;
                cursor: pointer;
                transition: all 0.2s ease;
            }

            .lcw-dot.active {
                background: #2196F3;
                transform: scale(1.25);
            }

            /* Responsive Design */
            @media (max-width: 1200px) {
                .lcw-product-item {
                    flex: 0 0 calc(33.333% - 11px);
                }
            }

            @media (max-width: 768px) {
                .lcw-product-item {
                    flex: 0 0 calc(50% - 8px);
                    min-width: 160px;
                }
                
                .lcw-carousel-container {
                    padding: 20px 50px;
                }
                
                .lcw-carousel-title {
                    font-size: 20px;
                }
                
                .lcw-carousel-nav {
                    width: 36px;
                    height: 36px;
                }
            }

            @media (max-width: 480px) {
                .lcw-product-item {
                    flex: 0 0 calc(100% - 0px);
                    min-width: 280px;
                }
                
                .lcw-carousel-container {
                    padding: 20px 40px;
                }
                
                .lcw-carousel-header {
                    padding: 20px 20px 12px;
                }
                
                .lcw-carousel-title {
                    font-size: 18px;
                }
            }
        `;

        if (!$('.lcw-carousel-style').length) {
            $('<style>').addClass('lcw-carousel-style').html(css).appendTo('head');
        }
    };

    const setEvents = () => {
        // Navigation events
        $(document).on('click', '.lcw-carousel-nav', function(e) {
            e.stopPropagation();
            const direction = $(this).data('direction');
            navigateCarousel(direction);
        });

        // Dot navigation
        $(document).on('click', '.lcw-dot', function(e) {
            e.stopPropagation();
            const slideIndex = $(this).data('slide');
            goToSlide(slideIndex);
        });

        // Product click - open in new tab
        $(document).on('click', '.lcw-product-card', function(e) {
            if ($(e.target).closest('.lcw-favorite-btn').length) return;
            
            const productId = $(this).closest('.lcw-product-item').data('product-id');
            const product = self.products.find(p => p.id === productId);
            
            if (product && product.url) {
                window.open(product.url, '_blank');
            }
        });

        // Favorite toggle
        $(document).on('click', '.lcw-favorite-btn', function(e) {
            e.stopPropagation();
            e.preventDefault();
            
            const productId = $(this).data('product-id');
            toggleFavorite(productId);
        });

        // Touch/swipe events for mobile
        let startX = 0;
        let currentX = 0;
        let isDragging = false;

        $(document).on('touchstart mousedown', '.lcw-carousel-track', function(e) {
            startX = e.type === 'mousedown' ? e.clientX : e.touches[0].clientX;
            isDragging = true;
            $(this).css('transition', 'none');
        });

        $(document).on('touchmove mousemove', '.lcw-carousel-track', function(e) {
            if (!isDragging) return;
            e.preventDefault();
            currentX = e.type === 'mousemove' ? e.clientX : e.touches[0].clientX;
        });

        $(document).on('touchend mouseup mouseleave', '.lcw-carousel-track', function() {
            if (!isDragging) return;
            isDragging = false;
            $(this).css('transition', '');
            
            const diff = startX - currentX;
            if (Math.abs(diff) > 50) {
                navigateCarousel(diff > 0 ? 'next' : 'prev');
            }
        });

        // Responsive handling
        $(window).on('resize', debounce(updateSlidesPerView, 200));

        // Keyboard navigation
        $(document).on('keydown', function(e) {
            if ($('.lcw-product-carousel').length === 0) return;
            
            if (e.keyCode === 37) { // Left arrow
                navigateCarousel('prev');
            } else if (e.keyCode === 39) { // Right arrow
                navigateCarousel('next');
            }
        });
    };

    const navigateCarousel = (direction) => {
        const totalSlides = Math.ceil(self.products.length / self.slidesPerView);
        
        if (direction === 'next') {
            self.currentSlide = (self.currentSlide + 1) % totalSlides;
        } else {
            self.currentSlide = self.currentSlide === 0 ? totalSlides - 1 : self.currentSlide - 1;
        }
        
        updateCarouselPosition();
        updateNavigationState();
        updateDots();
    };

    const goToSlide = (slideIndex) => {
        self.currentSlide = slideIndex;
        updateCarouselPosition();
        updateNavigationState();
        updateDots();
    };

    const updateCarouselPosition = () => {
        const translateX = -(self.currentSlide * 100);
        $('.lcw-carousel-track').css('transform', `translateX(${translateX}%)`);
    };

    const updateNavigationState = () => {
        const totalSlides = Math.ceil(self.products.length / self.slidesPerView);
        $('.lcw-nav-prev').prop('disabled', self.currentSlide === 0);
        $('.lcw-nav-next').prop('disabled', self.currentSlide === totalSlides - 1);
    };

    const updateDots = () => {
        $('.lcw-dot').removeClass('active');
        $(`.lcw-dot[data-slide="${self.currentSlide}"]`).addClass('active');
    };

    const updateSlidesPerView = () => {
        const width = $(window).width();
        let newSlidesPerView;
        
        if (width >= 1200) {
            newSlidesPerView = 4;
        } else if (width >= 768) {
            newSlidesPerView = 3;
        } else if (width >= 480) {
            newSlidesPerView = 2;
        } else {
            newSlidesPerView = 1;
        }
        
        if (newSlidesPerView !== self.slidesPerView) {
            self.slidesPerView = newSlidesPerView;
            self.currentSlide = 0;
            
            // Regenerate dots
            $('.lcw-carousel-dots').html(generateDots());
            updateCarouselPosition();
            updateNavigationState();
        }
    };

    const toggleFavorite = (productId) => {
        const $btn = $(`.lcw-favorite-btn[data-product-id="${productId}"]`);
        
        if (self.favorites.has(productId)) {
            self.favorites.delete(productId);
            $btn.removeClass('active');
        } else {
            self.favorites.add(productId);
            $btn.addClass('active');
        }
        
        saveFavorites();
        
        // Add animation effect
        $btn.addClass('animate');
        setTimeout(() => $btn.removeClass('animate'), 300);
    };

    const debounce = (func, wait) => {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    };

    // Run
    setTimeout(init, 100);
})();